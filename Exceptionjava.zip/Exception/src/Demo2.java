
public class Demo2 {

	public static void main(String[] args) throws NumberRange
	{
		int marks=30;
		try {
			if(marks<=35) {
				throw new NumberRange("failed ");
			}
		}
catch(NumberRange n) {
	System.out.println(n);
}
	}
}
class NumberRange extends Exception{
	public NumberRange(String message) {
		super(message);
	}
}
