import java.util.Scanner;
public class Demo1 {

	public static void main(String[] args) {
		for(int i=1;i<=10;i++)
		try {
//		String var=null;
		
//			System.out.println(var.charAt(3));
			if(i==5) {
				i=i/0;
			}
			System.out.println(i);
		}
		
	
	catch (Exception e)
	{
System.out.print(e);
System.out.println("exception in code"+e);

	}
		System.out.println("enter the number");
		int sum;
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		try {
		sum=num/0;
		System.out.println(sum);
		}
		
   catch (Exception e)
{
	System.out.println(e);
}
}
}