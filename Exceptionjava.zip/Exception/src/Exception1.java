
public class Exception1 {
	public static void main(String[] args) throws NumberRange
	{
		int number=-1;
		try {
			if(number<0) {
				throw new NumberRange("negative ");
				c=a%2
			    throw new NumberRange("positive");
			}
		}
catch(NumberRange n) {
	System.out.println(n);
}
		
		System.out.println("enterthe another number");
	}}

class NumberRange extends Exception{
	public NumberRange(String message) {
		super(message);

	}
	
}

