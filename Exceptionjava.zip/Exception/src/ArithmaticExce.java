
public class ArithmaticExce {

    public static void main(String[] args)  
    
    
    {
    	
    	 try{    
             String s=null;  
             int a[]=new int[5];
             System.out.println(a[10]); 
             System.out.println(s.length()); 
              
            }    
    	   catch(ArrayIndexOutOfBoundsException e)  
         {  
          System.out.println("ArrayIndexOutOfBounds Exception occurs");  
         }  
    	 
      catch(Exception e)  
         {  
          System.out.println("String exception");  
         }             
      System.out.println(" continue");  
    	 
    
    	 
    	 
    	
    	ArithmaticExce e = new ArithmaticExce();
       try {
    	   e.Example(5,5);
       }

       catch (ArithmeticException e1){
    	   System.out.println(e1);

       }
    }

public void Example(int x,int y) {
	int c;
	c=x/y;
	System.out.println(c);
}
}