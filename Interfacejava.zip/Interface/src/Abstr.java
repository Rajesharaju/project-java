

public class Abstr {

public static void main(String[] args) {
			Elephant e=new Elephant();
			e.eat();
			e.makeSound();

		}

	}
	abstract class Animal{
		 abstract void makeSound();
		 public void eat() {
			 System.out.println("greenary");
		 }
	}


	class Elephant extends  Animal{

		@Override
		void makeSound() {
			System.out.println("elephant sound");
			
		}
		}







