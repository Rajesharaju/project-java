
public interface A {
void meth1();

void meth2();
	
}

class MyClass implements A{
	
	public static void main (String a[]) {
		MyClass m=new MyClass();
		m.meth1();
		m.meth2();
	}
	public void meth1() {
		System.out.println("intreface execute");
	}
	public void meth2() {
		System.out.println("interface working");
			
	}
	
}