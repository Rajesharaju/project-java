import java.util.Scanner;
public interface Vechile {
	 double tuneupCost();
 boolean canCarry(int numpasse);
}

class Bus implements Vechile{
	Scanner sc =new Scanner(System.in);
	public static void main (String a[]) {
		Bus b=new Bus();
		b.tuneupCost();
		b.canCarry(10);
		
		
	}
public	double tuneupCost() {
//	int a=10;
//	int price;
//		System.out.println("the cost of travel");
//		int b=sc. nextInt();
//		price =a*b;
//		System.out.println(price);
	return 1000;
	}

public boolean canCarry(int numpasse) {
	int i=0;
	System.out.println("the number of passenger");
int c=sc.nextInt();
	
	if(c<=5) {
		System.out.println("passe allow");
	}
		else {
			System.out.println("not allow");
	}
	return true;
}
}
