
public class Abst {

	public static void main(String[] args) {
		Cars c=new Cars();
		c.brake();
		

	}

}
abstract class  MotorBike1{
	 abstract void brake();
	
}


class Cars extends MotorBike1{

	@Override
	void brake() {
		System.out.println("forthuneress");
		
	}


	}


