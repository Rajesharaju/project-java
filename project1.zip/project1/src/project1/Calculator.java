package project1;
//import java.util.Scanner;
//public class Calculator {
//
//	 public static void main(String aa[])
//	    {
//	        char choice;
//	        Scanner scan=new Scanner(System.in);  //2
//	        do {
//	        System.out.print("Enter first no"); //3
//	        int ch1= scan.nextInt();  //4
//	        System.out.print("Enter second no");
//	        int ch2= scan.nextInt(); 
//	        System.out.print("Select your operation :\n1.Addition\n2.Sub\n3.Mul\n4.Div");
//	        int op=scan.nextInt();
//	        if(op==1)
//	        {
//	            System.out.print("Addition :"+(ch1+ch2));
//	        }
//	        else if(op==2)
//	        {
//	            System.out.print("Subtraction :"+(ch1-ch2));
//	        }
//	        else if(op==3)
//	        {
//	            System.out.print("Mul :"+(ch1*ch2));
//	        }
//	        else if(op==4)
//	        {
//	            System.out.print("Division :"+(ch1/ch2));
//	        }else
//	        {
//	 
//	            System.out.print("Enter valid choice(1,2,3,4)");
//	        }
//	        System.out.print("Do you want to continue?(y/n)");
//	        choice=scan.next().charAt(0);
//	        }
//	        while(choice=='y' || choice=='Y');
//	        System.out.print("Thankyou!!!");
//	}
//	}



//bill


import java.util.Scanner;
public class Calculator {

	 public static void main(String aa[])
	    {
		 Scanner scan=new Scanner(System.in);
		 int c=50,t=20,s=30,f=100,u=80,d=50,total=0;
		 int choice;
		 
		 do {
		 System.out.print("Select your food :\n1.Brekfast\n2.lunch\n3.dinner");
	        int op=scan.nextInt();
	        if(op==1) {
	        	System.out.println("order items \n1.coffe \n2.tea\n3.sandwitch");
	        	int a=scan.nextInt();
	        	 System.out.println("total no of items");
	        	 int b=scan.nextInt();
	        	 total=b*c;
	        	 total=b*t;
	        	 total=b*s;
	        	 System.out.println("toatal amount "+total);
	        }
	        else if(op==2) {
	        	System.out.println("order items \n1.full meals \n2.south food\n3.uta");
	        	int a=scan.nextInt();
	        	 System.out.println("total no of items");
	        	 int b=scan.nextInt();
	        	 total=b*f;
	        	 total=b*t;
	        	 total=b*u;
	        	 System.out.println("toatal amount "+total);
	        		}
	        else  if(op==3) {
	        	System.out.println("order items \n1.uta \n2.driks\n3.sandwitch");
	        	int a=scan.nextInt();
	        	 System.out.println("total no of items");
	        	 int b=scan.nextInt();
	        	 total=b*u;
	        	 total=b*d;
	        	 total=b*s;
	        	 System.out.println("toatal amount "+total);
	    }
	        else
		        {
	 
	            System.out.print("Enter valid choice(1,2,3,4)");
	        }
	        System.out.print("Do you want to continue?(1/2,3)");
		        choice=scan.next().charAt(0);
		        
		 }
		        while(choice=='1' || choice=='2' || choice=='3');
		        System.out.print("Thankyou!!!");

	    }}