package project1;

//public class Intrest {
//
//	public static void main(String[] args) {
//		float P = 10, R = 15, T = 10;
//		 float SI = (P * T * R) / 100;
//	        System.out.println("Simple interest = " + SI);
//	}
//
//}







//public class Intrest{
//	
//public static void main( String args[]) {
//	Employee e=new Employee("100","10000");
//	System.out.println(e.getDetails());
//}
//}
//
//
//
//
//class Employee
//{
//	String id,salary;
//	
//	
//	
//Employee(String x,String sal)
//{
//	id=x;
//	salary=sal;
//}
// String getDetails(){
//	return id+""+salary;
//}
//	}

//public class Intrest {
//	
//public static void main(String args[]) {
//	Car c=new Car("jagvar","10000000");
//		System.out.println(	c.getdisplay());
//}
//}
//
//
//class Car{
//	String carbrand,price;
//
//Car(String br,String pr) 
//{
//	carbrand=br;
//	price=pr;
//	
//	}
//
//String getdisplay()
//{
//return carbrand+""+price;	
//}
//}


import java.util.Scanner;
public class Intrest {
int l,b,h;
Intrest(){
System.out.println("Enter the sides of triangle");
Scanner s=new Scanner(System.in);

l=s.nextInt();
b=s.nextInt();
h=s.nextInt();
int p=l+b+h;
int s2=p/2;
double sq =(s2*(s2-l)*(s2-b)*(s2-h));
double area=Math.sqrt(sq);
System.out.println("Area is: "+area+" Perimeter is: "+p);

}


public static void main(String args[]) {
	Intrest i=new Intrest();
}
}



