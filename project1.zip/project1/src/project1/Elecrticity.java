package project1;

public class Elecrticity {

	public static void main(String[] args) {
		int bills=100;
if(bills==50) {
	System.out.println("unitss are free");
}
else if(bills>=50 && bills<=100) {
	bills=(bills)-50*6+50;
System.out.println(bills);
}
else if(bills>=100 && bills<=150) {
	bills=(bills-50)*8+100;
System.out.println(bills);
}
else if(bills>=150 && bills<=200) {
	bills=(bills-50)*9+150;
System.out.println(bills);
	}
else
	System.out.println("ddefault units");
}
}






//bill for electricity
//units
//50 units are free
//51-100 units cost Rs6
//101-150 units cost Rs 8
//151-total units cost Rs 9 and