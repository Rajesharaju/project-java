package project1;
//import java.util.Scanner;
//public class Method {

//	
//	static int factorial(int n){    
//  if (n == 0)    
//    return 1;    
//  else    
//    return(n * factorial(n-1));    
// }    
// public static void main(String args[]){  
//  int i,fact=1;  
//  Scanner sc=new Scanner(System.in);
//  System.out.println("enter the number");
//  int num=sc.nextInt();
//     
//  fact = factorial(num);   
//  System.out.println("Factorial of "+num+" is: "+fact);    
//
// }
//}
//import java.util.Scanner;
//public class Method {
//	public static void main(String[] args) {
//	
//		final double Pi = 3.14;
//		double Radius;
//		Scanner in = new Scanner(System.in);
//		System.out.println("Enter the radius");
//		Radius = in.nextInt();
//		System.out.printf("The Area is (%.2f * %.2f)^2 = %.2f\n", Pi, Radius, Area(Pi,Radius));
//		System.out.printf("The Circumference is (2*%.2f*%.2f) = %.2f", Pi, Radius, Circumference(Pi, Radius));
//
//		}
//	public static double Area (double pi, double radius) {
//		double area = pi * Math.pow(radius, 2);
//		return area;
//		}
//
//		//2pi*r
//		public static double Circumference(double pi, double radius) {
//		double Cir = 2 * pi * radius;
//		return Cir;
//		}
//}
//



public class Method {
	
	 public static void main(String aa[])
	    {
	         Test t1=new Test();
	          t1.setName("raju");
	          t1.setRollno("23");

	          System.out.print(t1.getName()+"  "+t1.getRollno());
	}
}