package project1;

public class Bills {

	public static void main(String[] args) {
		int calls=200;
		if(calls==100) {
			calls=200*0;
System.out.println("calls are free rs 0");
		}
		else if(calls>=100 && calls<=200)
			calls=200-100*2;
			System.out.println("calls cost of 1");
		else if(calls>200 && calls<301)
			
			System.out.println("call cost rs 2");
		else if(calls>=301)
			System.out.println("call cost rs 3");
		else
			System.out.println("call are rejected");
	}

}
