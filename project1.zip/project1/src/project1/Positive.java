package project1;

public class Positive {

	public static void main(String[] args) {
		int no=-20;
		if(no==-20 || no==10)
			System.out.println("the number is positive");
		else
			System.out.println("the no is negative");

	}

}
