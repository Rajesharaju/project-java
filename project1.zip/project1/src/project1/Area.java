package project1;
//import java.util.Scanner;
//public class Area {
//	
//	
//		private static Scanner sc;
//
//		public static void main(String[] args) {
//			double width, height, Area; 
//			sc = new Scanner(System.in);
//			
//			System.out.println(" Please Enter the Width of a Rectangle =  ");
//			width = sc.nextDouble();
//			System.out.println(" Please Enter the Height of a Rectangle = ");
//			height = sc.nextDouble();
//
//			Area = width * height;
//			
//
//			System.out.format(" The Area of a Rectangle = %.2f\n",Area);
//			
//		}
//
//}
import java.util.Scanner;
public class Area {


public int area(int side)
{int sum;
    System.out.print("the area");{
    sum=side*side;
}
    return sum;
}
public float area(float radius)
{float sum;
    System.out.print("the radius is");{
    	sum=31.4f*radius*radius;
    }
    return sum;
}

public int area(int l,int b)
{int sum;
    System.out.print("the squre is");{
    	sum=l*b;
    }
    return sum;
}

public static void main(String aa[])
{
     System.out.print("Thankyou!!!");
     Area a=new Area();
    a.area(22.5f);
    a.area(2);
    a.area(3,9);
}
}