package project1;
import java.util.Scanner;
//public class Circle {
//
//	public static void main(String[] args) {
//		 Scanner s= new Scanner(System.in);
//	        
//         System.out.println("Enter the radius:");
//         double r= s.nextDouble();
//         double  area=(22*r*r)/7 ;
//         System.out.println("Area of Circle is: " + area);    
//
//	}
//
//}




public class Circle {

    
    public static void main(String aa[])
    {
         System.out.print("Thankyou!!!");
        Circle1 c=new Circle1(4);
        Circle1 c1=new Circle1(4);
//     System.out.println( c.getarea());
      System.out.println(c1.getarea1());   
}
}

class Circle1{
	int side,Area=1;
	float radius,Area1;
	Circle1()
	{
		System.out.println("Enter the sides of triangle");
		Scanner s1=new Scanner(System.in);
		   side=s1.nextInt();
		        Area=side*side;
		    }
		   Circle1(float rad){
			   System.out.println("Enter the sides radius");
			   Scanner s=new Scanner(System.in);
		    radius=s.nextInt();
		       Area1=31.4f*radius*radius;
		    }
		    void area(int l,int b)
		    {
		        System.out.print(l*b);
		    }
	
//int getarea()
//{
//	return Area;
//	
//}
float getarea1(){
	return Area1;

}

}