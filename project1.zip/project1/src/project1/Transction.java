package project1;
import java.util.Scanner;
public class Transction {
	Scanner sc=new Scanner(System.in);
 int acno;

 public int getAccountNum() 
 {
	 System.out.println("acno is");
  
{
 return acno;
 }
 }
 
 
void execute() {
System.out.println("the transction of customer details suceeful");	
}
}


class Balance extends Transction{
	
}

class Withdrawl extends Transction{
	
	int amount;
	int total=10000;
	{
	System.out.println("enter the with drawl amount");
	amount=sc.nextInt();
}
	void execute() {
		if(total<=0) {
		System.out.println("withdrawl sucess failure not enough bal");
		}
		
		else if (total>0 && total<=10000)
	System.out.println("withdraw is sucessful");
		else
			System.out.println("withdraw failure");
		}
}



class Deposit extends Transction{
	int amount;
	{
	System.out.println("enter the deposit amount");
amount=sc.nextInt();
	}
void execute() {
	System.out.println("deposit amount sucess"+super.acno);
}
}