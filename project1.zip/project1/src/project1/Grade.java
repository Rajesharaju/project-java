package project1;

public class Grade {

	public static void main(String[] args) {
		int marks =500;
		if(marks>=400)
			System.out.println(" a grade of pass");
		else if(marks>=300 && marks>=400)
			System.out.println("b grade");
		else
			System.out.println("fail");

	}

}
