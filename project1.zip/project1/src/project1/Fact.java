package project1;

public class Fact {

	public static void main(String[] args) {
		int factorial = 1;
        int number = 5;
        
        for(int i = 1; i <= number; i++)
        {
            factorial *= i;
        }
        
        System.out.println("Factorial of number " + number + " is " + factorial);
    
	}

}
