package project1;

//public class Test {
//
//	public static void main(String[] args) 
//	{
//	String name= "raju";
//	int age = 20;
//	String tech= "developer";
//	System.out.println("my name is " +name+ "\n i am learning "+tech+"\n age is "+age);
//    }   
//	}



//public class Test{
// String name,rollno;
//
//public String getName() {
//	return name;
//}
//
//public void setName(String name) {
//	this.name = name;
//}
//
//public String getRollno() {
//	return rollno;
//}
//
//public void setRollno(String rollno) {
//	this.rollno = rollno;
//}	
//}








//public class Test {
//
//    public static void main(String aa[])
//    {
//         Result r=new Result();
//         
//         r.readDetails();
//         r.readMarks();
//         r.displayDetails();
//         r.displayMarks();
//         r.calculatemarks();
//         r.Displayresult();
//}    
//}


public class Test{
	public static void main (String args[]) {
	Deposit d=new Deposit();
	Withdrawl w=new Withdrawl();
	Transction t=new Transction();
	Balance b=new Balance();
	int acno =123456;
	
	b.execute();
	w.execute();
	d.execute();
}}