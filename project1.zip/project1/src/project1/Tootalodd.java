package project1;

public class Tootalodd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number=50, i, oddSum = 0;
		for(i = 1; i <= number; i = i + 2)
		{
			oddSum = oddSum + i; 
		}
		System.out.println("\n The Sum of odd Numbers upto " + number + "  =  " + oddSum);
	
	}

}
