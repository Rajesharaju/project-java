package project1;

public class Division {

	public static void main(String[] args) {
		int number=1000, i, evenSum = 0;
//		sc = new Scanner(System.in);
		
//		System.out.print(" Please Enter any Number : ");
//		number = sc.nextInt();	
		
		for(i = 3; i <= number; i = i / 3)
		{
			evenSum = evenSum + i; 
		}
		System.out.println("\n The Sum of Even Numbers upto " + number + "  =  " + evenSum);
	}

}
