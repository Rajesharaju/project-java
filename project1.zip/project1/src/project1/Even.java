package project1;

public class Even {

	public static void main(String[] args) {
		int no=10;
		if(no==5 || no==10)
			System.out.println("the no is even");
		else
			System.out.println("the no is add");

	}

}
