package project1;

import java.util.Scanner;

public class Minh {
    Scanner s=new Scanner(System.in);
int studentId;
String studentname,phone;
 
void readDetails()
{
    System.out.println("Enter id");
    studentId=s.nextInt();
    System.out.println("Enter name");
    studentname=s.next();
    System.out.println("Enter phone");
    phone=s.next();
}
 
void displayDetails()
{
    System.out.println("ID :"+studentId);
    System.out.println("Name:"+studentname);
    System.out.println("Phoneno :"+phone);
}
}
 
class Mark extends Minh
{
    int m1,m2,m3;
 
    void readMarks()
    {
        System.out.println("marks of Maths");
        m1=s.nextInt();
        System.out.println("marks of English");
        m2=s.nextInt();
        System.out.println("marks of Hindi");
        m3=s.nextInt();
    }

    void displayMarks()
    {
        System.out.println("Marks ---\nMaths:"+m1);
        System.out.println("English:"+m2);
        System.out.println("hindi:"+m3);

    }
}

class Result extends Mark{
	float percent;
	int total=300;
	int result;
	String grade;
	void calculatemarks()
	{
		System.out.println("total marks");
		result=(m1+m2+m3);
		System.out.println(result);
		System.out.println("total percentage");
		percent=(result*100)/total;
		System.out.println(percent+"%");
		
	}

void Displayresult() 
{
	System.out.println("gradeof student");
	if(percent>=40)
	
		System.out.println("pass");
	
	else if (percent>=60) 
	{
		System.out.println("result is First class");
	}
	else {
		System.out.println("fail");
	}
}
}