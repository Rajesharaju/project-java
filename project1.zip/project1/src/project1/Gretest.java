package project1;

public class Gretest {

	public static void main(String[] args) {
		int n1=10,n2=15,n3=20,n4=30;
		if(n1>=n2  || n2>=n3 || n3>=n2) {
			System.out.println("the number is gretest");
		}
		else if(n1>=n2 || n2>=n3 )
			System.out.println("the n1 numberis lowest");
		else
			System.out.println("the number is lowest");
	}

}
