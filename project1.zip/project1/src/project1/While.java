package project1;

//public class While {
//
//	public static void main(String[] args) {
//		int num=2,i=1;
//		System.out.println("multiplication of 2");
//		while(i<=10) {
//			System.out.println(num+" * "+i+" = "+num*i);
//			i++;
//		}
//
//	}
//
//}


//public class While {
//
//	public static void main(String[] args) {
//		int num=2,i=1;
//		do {
//			System.out.println("multiplication of "+num+" * "+i+" = "+num*i);
//			i++;
//		}
//		while(i<10);
//		
//			
//		
//	}}



//factorial

public class While {

	public static void main(String[] args) {
		int f=1,n=5,m=5;
		while(n>0)
	      {				
	        f=f*n;
		    n--; 
		    
	      }
	     
		System.out.println("Factorial of "+m+" is = "+f);	
	}
}
	